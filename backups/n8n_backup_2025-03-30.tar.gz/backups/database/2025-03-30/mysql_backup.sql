-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: n8n
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `analytics_by_period`
--

DROP TABLE IF EXISTS `analytics_by_period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `analytics_by_period` (
  `id` int NOT NULL,
  `metaId` int NOT NULL,
  `type` int NOT NULL COMMENT '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure',
  `value` int NOT NULL,
  `periodUnit` int NOT NULL COMMENT '0: hour, 1: day, 2: week',
  `periodStart` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_20714d890d77beba8e3065367d` (`periodStart`,`type`,`periodUnit`,`metaId`),
  KEY `FK_83eea8e9024d109d055721dfb40` (`metaId`),
  CONSTRAINT `FK_83eea8e9024d109d055721dfb40` FOREIGN KEY (`metaId`) REFERENCES `analytics_metadata` (`metaId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_by_period`
--

LOCK TABLES `analytics_by_period` WRITE;
/*!40000 ALTER TABLE `analytics_by_period` DISABLE KEYS */;
/*!40000 ALTER TABLE `analytics_by_period` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `analytics_metadata`
--

DROP TABLE IF EXISTS `analytics_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `analytics_metadata` (
  `metaId` int NOT NULL,
  `workflowId` varchar(16) DEFAULT NULL,
  `projectId` varchar(36) DEFAULT NULL,
  `workflowName` varchar(128) NOT NULL,
  `projectName` varchar(255) NOT NULL,
  PRIMARY KEY (`metaId`),
  KEY `FK_b14a2a0105c036afaa293b1c57e` (`workflowId`),
  KEY `FK_b06b8962721cf6ef7a508d52a66` (`projectId`),
  CONSTRAINT `FK_b06b8962721cf6ef7a508d52a66` FOREIGN KEY (`projectId`) REFERENCES `project` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_b14a2a0105c036afaa293b1c57e` FOREIGN KEY (`workflowId`) REFERENCES `workflow_entity` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_metadata`
--

LOCK TABLES `analytics_metadata` WRITE;
/*!40000 ALTER TABLE `analytics_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `analytics_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `analytics_raw`
--

DROP TABLE IF EXISTS `analytics_raw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `analytics_raw` (
  `id` int NOT NULL,
  `metaId` int NOT NULL,
  `type` int NOT NULL COMMENT '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure',
  `value` int NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_e4cdf6fe2f1d8a494da5569ed13` (`metaId`),
  CONSTRAINT `FK_e4cdf6fe2f1d8a494da5569ed13` FOREIGN KEY (`metaId`) REFERENCES `analytics_metadata` (`metaId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_raw`
--

LOCK TABLES `analytics_raw` WRITE;
/*!40000 ALTER TABLE `analytics_raw` DISABLE KEYS */;
/*!40000 ALTER TABLE `analytics_raw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `annotation_tag_entity`
--

DROP TABLE IF EXISTS `annotation_tag_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `annotation_tag_entity` (
  `id` varchar(16) NOT NULL,
  `name` varchar(24) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_ae51b54c4bb430cf92f48b623f` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annotation_tag_entity`
--

LOCK TABLES `annotation_tag_entity` WRITE;
/*!40000 ALTER TABLE `annotation_tag_entity` DISABLE KEYS */;
/*!40000 ALTER TABLE `annotation_tag_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_identity`
--

DROP TABLE IF EXISTS `auth_identity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_identity` (
  `userId` varchar(36) DEFAULT NULL,
  `providerId` varchar(64) NOT NULL,
  `providerType` varchar(32) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`providerId`,`providerType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_identity`
--

LOCK TABLES `auth_identity` WRITE;
/*!40000 ALTER TABLE `auth_identity` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_identity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_provider_sync_history`
--

DROP TABLE IF EXISTS `auth_provider_sync_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_provider_sync_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `providerType` varchar(32) NOT NULL,
  `runMode` text NOT NULL,
  `status` text NOT NULL,
  `startedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `endedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `scanned` int NOT NULL,
  `created` int NOT NULL,
  `updated` int NOT NULL,
  `disabled` int NOT NULL,
  `error` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_provider_sync_history`
--

LOCK TABLES `auth_provider_sync_history` WRITE;
/*!40000 ALTER TABLE `auth_provider_sync_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_provider_sync_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credentials_entity`
--

DROP TABLE IF EXISTS `credentials_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credentials_entity` (
  `name` varchar(128) NOT NULL,
  `data` text NOT NULL,
  `type` varchar(128) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `isManaged` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_07fde106c0b471d8cc80a64fc8` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credentials_entity`
--

LOCK TABLES `credentials_entity` WRITE;
/*!40000 ALTER TABLE `credentials_entity` DISABLE KEYS */;
/*!40000 ALTER TABLE `credentials_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_destinations`
--

DROP TABLE IF EXISTS `event_destinations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_destinations` (
  `id` varchar(36) NOT NULL,
  `destination` text NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_destinations`
--

LOCK TABLES `event_destinations` WRITE;
/*!40000 ALTER TABLE `event_destinations` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_destinations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `execution_annotation_tags`
--

DROP TABLE IF EXISTS `execution_annotation_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `execution_annotation_tags` (
  `annotationId` int NOT NULL,
  `tagId` varchar(24) NOT NULL,
  PRIMARY KEY (`annotationId`,`tagId`),
  KEY `IDX_a3697779b366e131b2bbdae297` (`tagId`),
  KEY `IDX_c1519757391996eb06064f0e7c` (`annotationId`),
  CONSTRAINT `FK_a3697779b366e131b2bbdae2976` FOREIGN KEY (`tagId`) REFERENCES `annotation_tag_entity` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_c1519757391996eb06064f0e7c8` FOREIGN KEY (`annotationId`) REFERENCES `execution_annotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `execution_annotation_tags`
--

LOCK TABLES `execution_annotation_tags` WRITE;
/*!40000 ALTER TABLE `execution_annotation_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `execution_annotation_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `execution_annotations`
--

DROP TABLE IF EXISTS `execution_annotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `execution_annotations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `executionId` int NOT NULL,
  `vote` varchar(6) DEFAULT NULL,
  `note` text,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_97f863fa83c4786f1956508496` (`executionId`),
  CONSTRAINT `FK_97f863fa83c4786f19565084960` FOREIGN KEY (`executionId`) REFERENCES `execution_entity` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `execution_annotations`
--

LOCK TABLES `execution_annotations` WRITE;
/*!40000 ALTER TABLE `execution_annotations` DISABLE KEYS */;
/*!40000 ALTER TABLE `execution_annotations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `execution_data`
--

DROP TABLE IF EXISTS `execution_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `execution_data` (
  `executionId` int NOT NULL,
  `workflowData` json NOT NULL,
  `data` mediumtext,
  PRIMARY KEY (`executionId`),
  CONSTRAINT `execution_data_FK` FOREIGN KEY (`executionId`) REFERENCES `execution_entity` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `execution_data`
--

LOCK TABLES `execution_data` WRITE;
/*!40000 ALTER TABLE `execution_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `execution_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `execution_entity`
--

DROP TABLE IF EXISTS `execution_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `execution_entity` (
  `id` int NOT NULL AUTO_INCREMENT,
  `finished` tinyint NOT NULL,
  `mode` varchar(255) NOT NULL,
  `retryOf` varchar(255) DEFAULT NULL,
  `retrySuccessId` varchar(255) DEFAULT NULL,
  `startedAt` datetime DEFAULT NULL,
  `stoppedAt` datetime DEFAULT NULL,
  `waitTill` datetime DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `workflowId` varchar(36) NOT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `IDX_execution_entity_deletedAt` (`deletedAt`),
  KEY `IDX_execution_entity_workflowId_startedAt` (`workflowId`,`startedAt`),
  KEY `IDX_execution_entity_waitTill_status_deletedAt` (`waitTill`,`status`,`deletedAt`),
  KEY `IDX_execution_entity_stoppedAt_status_deletedAt` (`stoppedAt`,`status`,`deletedAt`),
  CONSTRAINT `fk_execution_entity_workflow_id` FOREIGN KEY (`workflowId`) REFERENCES `workflow_entity` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `execution_entity`
--

LOCK TABLES `execution_entity` WRITE;
/*!40000 ALTER TABLE `execution_entity` DISABLE KEYS */;
/*!40000 ALTER TABLE `execution_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `execution_metadata`
--

DROP TABLE IF EXISTS `execution_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `execution_metadata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `executionId` int NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_cec8eea3bf49551482ccb4933e` (`executionId`,`key`),
  CONSTRAINT `gPfNkZ02sOA2-aVClrt0J` FOREIGN KEY (`executionId`) REFERENCES `execution_entity` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `execution_metadata`
--

LOCK TABLES `execution_metadata` WRITE;
/*!40000 ALTER TABLE `execution_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `execution_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder`
--

DROP TABLE IF EXISTS `folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `folder` (
  `id` varchar(36) NOT NULL,
  `name` varchar(128) NOT NULL,
  `parentFolderId` varchar(36) DEFAULT NULL,
  `projectId` varchar(36) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_14f68deffaf858465715995508` (`projectId`,`id`),
  KEY `FK_804ea52f6729e3940498bd54d78` (`parentFolderId`),
  CONSTRAINT `FK_804ea52f6729e3940498bd54d78` FOREIGN KEY (`parentFolderId`) REFERENCES `folder` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_a8260b0b36939c6247f385b8221` FOREIGN KEY (`projectId`) REFERENCES `project` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder`
--

LOCK TABLES `folder` WRITE;
/*!40000 ALTER TABLE `folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder_tag`
--

DROP TABLE IF EXISTS `folder_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `folder_tag` (
  `folderId` varchar(36) NOT NULL,
  `tagId` varchar(36) NOT NULL,
  PRIMARY KEY (`folderId`,`tagId`),
  KEY `FK_dc88164176283de80af47621746` (`tagId`),
  CONSTRAINT `FK_94a60854e06f2897b2e0d39edba` FOREIGN KEY (`folderId`) REFERENCES `folder` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_dc88164176283de80af47621746` FOREIGN KEY (`tagId`) REFERENCES `tag_entity` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder_tag`
--

LOCK TABLES `folder_tag` WRITE;
/*!40000 ALTER TABLE `folder_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `folder_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `installed_nodes`
--

DROP TABLE IF EXISTS `installed_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `installed_nodes` (
  `name` char(200) NOT NULL,
  `type` char(200) NOT NULL,
  `latestVersion` int NOT NULL DEFAULT '1',
  `package` char(214) NOT NULL,
  PRIMARY KEY (`name`),
  KEY `FK_73f857fc5dce682cef8a99c11dbddbc969618951` (`package`),
  CONSTRAINT `FK_73f857fc5dce682cef8a99c11dbddbc969618951` FOREIGN KEY (`package`) REFERENCES `installed_packages` (`packageName`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `installed_nodes`
--

LOCK TABLES `installed_nodes` WRITE;
/*!40000 ALTER TABLE `installed_nodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `installed_nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `installed_packages`
--

DROP TABLE IF EXISTS `installed_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `installed_packages` (
  `packageName` char(214) NOT NULL,
  `installedVersion` char(50) NOT NULL,
  `authorName` char(70) DEFAULT NULL,
  `authorEmail` char(70) DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`packageName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `installed_packages`
--

LOCK TABLES `installed_packages` WRITE;
/*!40000 ALTER TABLE `installed_packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `installed_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invalid_auth_token`
--

DROP TABLE IF EXISTS `invalid_auth_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invalid_auth_token` (
  `token` varchar(512) NOT NULL,
  `expiresAt` datetime(3) NOT NULL,
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invalid_auth_token`
--

LOCK TABLES `invalid_auth_token` WRITE;
/*!40000 ALTER TABLE `invalid_auth_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `invalid_auth_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` bigint NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,1588157391238,'InitialMigration1588157391238'),(2,1592447867632,'WebhookModel1592447867632'),(3,1594902918301,'CreateIndexStoppedAt1594902918301'),(4,1607431743767,'MakeStoppedAtNullable1607431743767'),(5,1611149998770,'AddWebhookId1611149998770'),(6,1615306975123,'ChangeDataSize1615306975123'),(7,1617268711084,'CreateTagEntity1617268711084'),(8,1620729500000,'ChangeCredentialDataSize1620729500000'),(9,1620826335440,'UniqueWorkflowNames1620826335440'),(10,1623936588000,'CertifyCorrectCollation1623936588000'),(11,1626183952959,'AddWaitColumnId1626183952959'),(12,1630451444017,'UpdateWorkflowCredentials1630451444017'),(13,1644424784709,'AddExecutionEntityIndexes1644424784709'),(14,1646992772331,'CreateUserManagement1646992772331'),(15,1648740597343,'LowerCaseUserEmail1648740597343'),(16,1652254514003,'CommunityNodes1652254514003'),(17,1652367743993,'AddUserSettings1652367743993'),(18,1652905585850,'AddAPIKeyColumn1652905585850'),(19,1654090101303,'IntroducePinData1654090101303'),(20,1658932910559,'AddNodeIds1658932910559'),(21,1659895550980,'AddJsonKeyPinData1659895550980'),(22,1660062385367,'CreateCredentialsUserRole1660062385367'),(23,1663755770894,'CreateWorkflowsEditorRole1663755770894'),(24,1664196174002,'WorkflowStatistics1664196174002'),(25,1665484192213,'CreateCredentialUsageTable1665484192213'),(26,1665754637026,'RemoveCredentialUsageTable1665754637026'),(27,1669739707125,'AddWorkflowVersionIdColumn1669739707125'),(28,1669823906994,'AddTriggerCountColumn1669823906994'),(29,1671535397530,'MessageEventBusDestinations1671535397530'),(30,1671726148420,'RemoveWorkflowDataLoadedFlag1671726148420'),(31,1673268682475,'DeleteExecutionsWithWorkflows1673268682475'),(32,1674138566000,'AddStatusToExecutions1674138566000'),(33,1674509946020,'CreateLdapEntities1674509946020'),(34,1675940580449,'PurgeInvalidWorkflowConnections1675940580449'),(35,1676996103000,'MigrateExecutionStatus1676996103000'),(36,1677236788851,'UpdateRunningExecutionStatus1677236788851'),(37,1677501636753,'CreateVariables1677501636753'),(38,1679416281779,'CreateExecutionMetadataTable1679416281779'),(39,1681134145996,'AddUserActivatedProperty1681134145996'),(40,1681134145997,'RemoveSkipOwnerSetup1681134145997'),(41,1690000000001,'MigrateIntegerKeysToString1690000000001'),(42,1690000000030,'SeparateExecutionData1690000000030'),(43,1690000000030,'RemoveResetPasswordColumns1690000000030'),(44,1690000000030,'AddMfaColumns1690000000030'),(45,1690000000031,'FixExecutionDataType1690000000031'),(46,1691088862123,'CreateWorkflowNameIndex1691088862123'),(47,1692967111175,'CreateWorkflowHistoryTable1692967111175'),(48,1693491613982,'ExecutionSoftDelete1693491613982'),(49,1693554410387,'DisallowOrphanExecutions1693554410387'),(50,1695128658538,'AddWorkflowMetadata1695128658538'),(51,1695829275184,'ModifyWorkflowHistoryNodesAndConnections1695829275184'),(52,1700571993961,'AddGlobalAdminRole1700571993961'),(53,1705429061930,'DropRoleMapping1705429061930'),(54,1711018413374,'RemoveFailedExecutionStatus1711018413374'),(55,1711390882123,'MoveSshKeysToDatabase1711390882123'),(56,1712044305787,'RemoveNodesAccess1712044305787'),(57,1714133768519,'CreateProject1714133768519'),(58,1714133768521,'MakeExecutionStatusNonNullable1714133768521'),(59,1717498465931,'AddActivatedAtUserSetting1717498465931'),(60,1720101653148,'AddConstraintToExecutionMetadata1720101653148'),(61,1723627610222,'CreateInvalidAuthTokenTable1723627610222'),(62,1723796243146,'RefactorExecutionIndices1723796243146'),(63,1724753530828,'CreateAnnotationTables1724753530828'),(64,1724951148974,'AddApiKeysTable1724951148974'),(65,1726606152711,'CreateProcessedDataTable1726606152711'),(66,1727427440136,'SeparateExecutionCreationFromStart1727427440136'),(67,1728659839644,'AddMissingPrimaryKeyOnAnnotationTagMapping1728659839644'),(68,1729607673464,'UpdateProcessedDataValueColumnToText1729607673464'),(69,1729607673469,'AddProjectIcons1729607673469'),(70,1730386903556,'CreateTestDefinitionTable1730386903556'),(71,1731404028106,'AddDescriptionToTestDefinition1731404028106'),(72,1731582748663,'MigrateTestDefinitionKeyToString1731582748663'),(73,1732271325258,'CreateTestMetricTable1732271325258'),(74,1732549866705,'CreateTestRun1732549866705'),(75,1733133775640,'AddMockedNodesColumnToTestDefinition1733133775640'),(76,1734479635324,'AddManagedColumnToCredentialsTable1734479635324'),(77,1736172058779,'AddStatsColumnsToTestRun1736172058779'),(78,1736947513045,'CreateTestCaseExecutionTable1736947513045'),(79,1737715421462,'AddErrorColumnsToTestRuns1737715421462'),(80,1738709609940,'CreateFolderTable1738709609940'),(81,1739549398681,'CreateAnalyticsTables1739549398681'),(82,1739873751194,'FixTestDefinitionPrimaryKey1739873751194'),(83,1740445074052,'UpdateParentFolderIdColumn1740445074052');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `processed_data`
--

DROP TABLE IF EXISTS `processed_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `processed_data` (
  `workflowId` varchar(36) NOT NULL,
  `context` varchar(255) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `value` text NOT NULL,
  PRIMARY KEY (`workflowId`,`context`),
  CONSTRAINT `FK_06a69a7032c97a763c2c7599464` FOREIGN KEY (`workflowId`) REFERENCES `workflow_entity` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `processed_data`
--

LOCK TABLES `processed_data` WRITE;
/*!40000 ALTER TABLE `processed_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `processed_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(36) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `icon` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES ('iqWnxdJNjhYw4zb9','yonatan kadosh <yonatankm@gmail.com>','personal','2025-03-30 08:02:13.007','2025-03-30 08:03:31.019',NULL);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_relation`
--

DROP TABLE IF EXISTS `project_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_relation` (
  `projectId` varchar(36) NOT NULL,
  `userId` varchar(36) NOT NULL,
  `role` varchar(255) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`projectId`,`userId`),
  KEY `IDX_61448d56d61802b5dfde5cdb00` (`projectId`),
  KEY `IDX_5f0643f6717905a05164090dde` (`userId`),
  CONSTRAINT `FK_5f0643f6717905a05164090dde7` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_61448d56d61802b5dfde5cdb002` FOREIGN KEY (`projectId`) REFERENCES `project` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_relation`
--

LOCK TABLES `project_relation` WRITE;
/*!40000 ALTER TABLE `project_relation` DISABLE KEYS */;
INSERT INTO `project_relation` VALUES ('iqWnxdJNjhYw4zb9','b16a6a5a-b226-4f19-b2c0-ca74874ddb5f','project:personalOwner','2025-03-30 08:02:13.008','2025-03-30 08:02:13.008');
/*!40000 ALTER TABLE `project_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `scope` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_5b49d0f504f7ef31045a1fb2eb8` (`scope`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'owner','global','2025-03-30 08:02:10','2025-03-30 08:02:10'),(2,'member','global','2025-03-30 08:02:10','2025-03-30 08:02:10'),(3,'owner','workflow','2025-03-30 08:02:10','2025-03-30 08:02:10'),(4,'owner','credential','2025-03-30 08:02:10','2025-03-30 08:02:10'),(5,'user','credential','2025-03-30 08:02:10','2025-03-30 08:02:10'),(6,'editor','workflow','2025-03-30 08:02:10','2025-03-30 08:02:10'),(7,'admin','global','2025-03-30 08:02:12','2025-03-30 08:02:12');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `loadOnStartup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('features.ldap','{\"loginEnabled\":false,\"loginLabel\":\"\",\"connectionUrl\":\"\",\"allowUnauthorizedCerts\":false,\"connectionSecurity\":\"none\",\"connectionPort\":389,\"baseDn\":\"\",\"bindingAdminDn\":\"\",\"bindingAdminPassword\":\"\",\"firstNameAttribute\":\"\",\"lastNameAttribute\":\"\",\"emailAttribute\":\"\",\"loginIdAttribute\":\"\",\"ldapIdAttribute\":\"\",\"userFilter\":\"\",\"synchronizationEnabled\":false,\"synchronizationInterval\":60,\"searchPageSize\":0,\"searchTimeout\":60}',1),('features.sourceControl','{\"branchName\":\"main\",\"keyGeneratorType\":\"ed25519\"}',1),('features.sourceControl.sshKeys','{\"encryptedPrivateKey\":\"U2FsdGVkX19iNWFeO28LyT/wTbw3P/fKb8p+in76pHwXadUXknpvUSyojMYOf72Vzn8p7nN3YDVD2qru3nFpgac+B5Ti0ov+WcJvPg6f4T7WlhhRrNR+pHs79/NaHWOvnCUNgj2oQQCAEWwMXqwHdss4Sb6QWz0zy8XbzZVWR/8uhroV4djxo0ajS//NY5IcI4x8qITRRzTx3a5CpxXiDQt+5/oJ43qzOaUw7WpWSlg1YKNxlH0C2FTZ8n8in2Env0aQT6QeXQolVewFBe+U8wRv1ehNqevqYaNkJAbO8uNtQthEqrUVsBONN8LLtylGNbeLBBSTtqbj55BIMjweGZURKU6spBJEOxBJMCrmpEvtiNM4+BEyiuc7Af8Wg4rvvHW7mYIuNTjQB/p1h315GCOQsvyBit7hTXjQIgYOgnIc8hMM+X8Ti1mkLUJBMnJ9PtqxXl/B7veK4awTn0zoURQke7OYCePhVRdOEthIRuhnUo5BU6+KtpN7XcrhmegguzqNr/SC3SriOrwf9PCM9CeHdJn6pSV4sMvulQX2P2jQYWqQa7F4gvsNsnstNKnx\",\"publicKey\":\"ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIF79aGeP3xzxFo/fNqDWAXX1T1Ook2Rl/dsMW76ZvgDC n8n deploy key\"}',1),('ui.banners.dismissed','[\"V1\"]',1),('userManagement.isInstanceOwnerSetUp','true',1);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shared_credentials`
--

DROP TABLE IF EXISTS `shared_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shared_credentials` (
  `credentialsId` varchar(36) NOT NULL,
  `projectId` varchar(36) NOT NULL,
  `role` text NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`credentialsId`,`projectId`),
  KEY `FK_812c2852270da1247756e77f5a4` (`projectId`),
  CONSTRAINT `FK_416f66fc846c7c442970c094ccf` FOREIGN KEY (`credentialsId`) REFERENCES `credentials_entity` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_812c2852270da1247756e77f5a4` FOREIGN KEY (`projectId`) REFERENCES `project` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shared_credentials`
--

LOCK TABLES `shared_credentials` WRITE;
/*!40000 ALTER TABLE `shared_credentials` DISABLE KEYS */;
/*!40000 ALTER TABLE `shared_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shared_workflow`
--

DROP TABLE IF EXISTS `shared_workflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shared_workflow` (
  `workflowId` varchar(36) NOT NULL,
  `projectId` varchar(36) NOT NULL,
  `role` text NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`workflowId`,`projectId`),
  KEY `FK_a45ea5f27bcfdc21af9b4188560` (`projectId`),
  CONSTRAINT `FK_a45ea5f27bcfdc21af9b4188560` FOREIGN KEY (`projectId`) REFERENCES `project` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_daa206a04983d47d0a9c34649ce` FOREIGN KEY (`workflowId`) REFERENCES `workflow_entity` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shared_workflow`
--

LOCK TABLES `shared_workflow` WRITE;
/*!40000 ALTER TABLE `shared_workflow` DISABLE KEYS */;
INSERT INTO `shared_workflow` VALUES ('fj91AMu4CaRTZRBz','iqWnxdJNjhYw4zb9','workflow:owner','2025-03-30 08:09:41.802','2025-03-30 08:09:41.802'),('h75fjPi1F3ONvBws','iqWnxdJNjhYw4zb9','workflow:owner','2025-03-30 08:05:48.571','2025-03-30 08:05:48.571');
/*!40000 ALTER TABLE `shared_workflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_entity`
--

DROP TABLE IF EXISTS `tag_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_entity` (
  `name` varchar(24) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_8f949d7a3a984759044054e89b` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_entity`
--

LOCK TABLES `tag_entity` WRITE;
/*!40000 ALTER TABLE `tag_entity` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_case_execution`
--

DROP TABLE IF EXISTS `test_case_execution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_case_execution` (
  `id` varchar(36) NOT NULL,
  `testRunId` varchar(36) NOT NULL,
  `pastExecutionId` int DEFAULT NULL,
  `executionId` int DEFAULT NULL,
  `evaluationExecutionId` int DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `runAt` datetime(3) DEFAULT NULL,
  `completedAt` datetime(3) DEFAULT NULL,
  `errorCode` varchar(255) DEFAULT NULL,
  `errorDetails` json DEFAULT NULL,
  `metrics` json DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `IDX_8e4b4774db42f1e6dda3452b2a` (`testRunId`),
  KEY `FK_258d954733841d51edd826a562b` (`pastExecutionId`),
  KEY `FK_e48965fac35d0f5b9e7f51d8c44` (`executionId`),
  KEY `FK_dfbe194e3ebdfe49a87bc4692ca` (`evaluationExecutionId`),
  CONSTRAINT `FK_258d954733841d51edd826a562b` FOREIGN KEY (`pastExecutionId`) REFERENCES `execution_entity` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_8e4b4774db42f1e6dda3452b2af` FOREIGN KEY (`testRunId`) REFERENCES `test_run` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_dfbe194e3ebdfe49a87bc4692ca` FOREIGN KEY (`evaluationExecutionId`) REFERENCES `execution_entity` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_e48965fac35d0f5b9e7f51d8c44` FOREIGN KEY (`executionId`) REFERENCES `execution_entity` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_case_execution`
--

LOCK TABLES `test_case_execution` WRITE;
/*!40000 ALTER TABLE `test_case_execution` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_case_execution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_definition`
--

DROP TABLE IF EXISTS `test_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_definition` (
  `name` varchar(255) NOT NULL,
  `workflowId` varchar(36) NOT NULL,
  `evaluationWorkflowId` varchar(36) DEFAULT NULL,
  `annotationTagId` varchar(16) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `description` text,
  `id` varchar(36) NOT NULL,
  `mockedNodes` json NOT NULL DEFAULT (_utf8mb4'[]'),
  PRIMARY KEY (`id`),
  KEY `IDX_b0dd0087fe3da02b0ffa4b9c5b` (`workflowId`),
  KEY `IDX_9ec1ce6fbf82305f489adb971d` (`evaluationWorkflowId`),
  KEY `FK_d5d7ea64662dbc62f5e266fbeb0` (`annotationTagId`),
  CONSTRAINT `FK_9ec1ce6fbf82305f489adb971d3` FOREIGN KEY (`evaluationWorkflowId`) REFERENCES `workflow_entity` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_b0dd0087fe3da02b0ffa4b9c5bb` FOREIGN KEY (`workflowId`) REFERENCES `workflow_entity` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_d5d7ea64662dbc62f5e266fbeb0` FOREIGN KEY (`annotationTagId`) REFERENCES `annotation_tag_entity` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_definition`
--

LOCK TABLES `test_definition` WRITE;
/*!40000 ALTER TABLE `test_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_metric`
--

DROP TABLE IF EXISTS `test_metric`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_metric` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `testDefinitionId` varchar(36) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `IDX_3a4e9cf37111ac3270e2469b47` (`testDefinitionId`),
  CONSTRAINT `FK_3a4e9cf37111ac3270e2469b475` FOREIGN KEY (`testDefinitionId`) REFERENCES `test_definition` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_metric`
--

LOCK TABLES `test_metric` WRITE;
/*!40000 ALTER TABLE `test_metric` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_metric` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_run`
--

DROP TABLE IF EXISTS `test_run`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_run` (
  `id` varchar(36) NOT NULL,
  `testDefinitionId` varchar(36) NOT NULL,
  `status` varchar(255) NOT NULL,
  `runAt` datetime(3) DEFAULT NULL,
  `completedAt` datetime(3) DEFAULT NULL,
  `metrics` json DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `totalCases` int DEFAULT NULL,
  `passedCases` int DEFAULT NULL,
  `failedCases` int DEFAULT NULL,
  `errorCode` varchar(255) DEFAULT NULL,
  `errorDetails` text,
  PRIMARY KEY (`id`),
  KEY `IDX_3a81713a76f2295b12b46cdfca` (`testDefinitionId`),
  CONSTRAINT `FK_3a81713a76f2295b12b46cdfcab` FOREIGN KEY (`testDefinitionId`) REFERENCES `test_definition` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_run`
--

LOCK TABLES `test_run` WRITE;
/*!40000 ALTER TABLE `test_run` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_run` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` varchar(36) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `firstName` varchar(32) DEFAULT NULL,
  `lastName` varchar(32) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `personalizationAnswers` json DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `settings` json DEFAULT NULL,
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `mfaEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `mfaSecret` text,
  `mfaRecoveryCodes` text,
  `role` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_e12875dfb3b1d92d7d7c5377e2` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('b16a6a5a-b226-4f19-b2c0-ca74874ddb5f','yonatankm@gmail.com','yonatan','kadosh','$2a$10$imveoXi9f2.wh4sNXMcs/uaLzGLu13qxITLuI7jdNawt8SNqywtfC','{\"role\": \"engineering\", \"version\": \"v4\", \"companyType\": \"saas\", \"automationGoalDevops\": [\"data-syncing\", \"monitoring-alerting\"], \"personalization_survey_n8n_version\": \"1.83.2\", \"personalization_survey_submitted_at\": \"2025-03-30T08:04:07.834Z\"}','2025-03-30 08:02:10','2025-03-30 08:05:49','{\"userActivated\": false, \"easyAIWorkflowOnboarded\": true}',0,0,NULL,NULL,'global:owner');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_api_keys`
--

DROP TABLE IF EXISTS `user_api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_api_keys` (
  `id` varchar(36) NOT NULL,
  `userId` varchar(36) NOT NULL,
  `label` varchar(100) NOT NULL,
  `apiKey` varchar(255) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_63d7bbae72c767cf162d459fcc` (`userId`,`label`),
  UNIQUE KEY `IDX_1ef35bac35d20bdae979d917a3` (`apiKey`),
  CONSTRAINT `FK_e131705cbbc8fb589889b02d457` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_api_keys`
--

LOCK TABLES `user_api_keys` WRITE;
/*!40000 ALTER TABLE `user_api_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `variables`
--

DROP TABLE IF EXISTS `variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variables` (
  `key` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'string',
  `value` varchar(255) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variables`
--

LOCK TABLES `variables` WRITE;
/*!40000 ALTER TABLE `variables` DISABLE KEYS */;
/*!40000 ALTER TABLE `variables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_entity`
--

DROP TABLE IF EXISTS `webhook_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_entity` (
  `webhookPath` varchar(255) NOT NULL,
  `method` varchar(255) NOT NULL,
  `node` varchar(255) NOT NULL,
  `webhookId` varchar(255) DEFAULT NULL,
  `pathLength` int DEFAULT NULL,
  `workflowId` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`webhookPath`,`method`),
  KEY `IDX_742496f199721a057051acf4c2` (`webhookId`,`method`,`pathLength`),
  KEY `fk_webhook_entity_workflow_id` (`workflowId`),
  CONSTRAINT `fk_webhook_entity_workflow_id` FOREIGN KEY (`workflowId`) REFERENCES `workflow_entity` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_entity`
--

LOCK TABLES `webhook_entity` WRITE;
/*!40000 ALTER TABLE `webhook_entity` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflow_entity`
--

DROP TABLE IF EXISTS `workflow_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_entity` (
  `name` varchar(128) NOT NULL,
  `active` tinyint NOT NULL,
  `nodes` json NOT NULL,
  `connections` json NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `settings` json DEFAULT NULL,
  `staticData` json DEFAULT NULL,
  `pinData` json DEFAULT NULL,
  `versionId` char(36) DEFAULT NULL,
  `triggerCount` int NOT NULL DEFAULT '0',
  `id` varchar(36) NOT NULL,
  `meta` json DEFAULT NULL,
  `parentFolderId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_workflow_entity_name` (`name`),
  KEY `fk_workflow_parent_folder` (`parentFolderId`),
  CONSTRAINT `fk_workflow_parent_folder` FOREIGN KEY (`parentFolderId`) REFERENCES `folder` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_entity`
--

LOCK TABLES `workflow_entity` WRITE;
/*!40000 ALTER TABLE `workflow_entity` DISABLE KEYS */;
INSERT INTO `workflow_entity` VALUES ('My workflow',0,'[{\"id\": \"7602ed56-c376-4be2-bc67-cad45f0570d1\", \"name\": \"Google Sheets Trigger\", \"type\": \"n8n-nodes-base.googleSheetsTrigger\", \"position\": [-1600, 140], \"parameters\": {\"options\": {}, \"pollTimes\": {\"item\": [{\"mode\": \"everyMinute\"}]}, \"sheetName\": {\"__rl\": true, \"mode\": \"list\", \"value\": \"gid=0\", \"cachedResultUrl\": \"https://docs.google.com/spreadsheets/d/1kBzpaLtXwvksjq1rA2DzAppDFtSV8Pcc8Lh9DXDKoOo/edit#gid=0\", \"cachedResultName\": \"Sheet1\"}, \"documentId\": {\"__rl\": true, \"mode\": \"list\", \"value\": \"1kBzpaLtXwvksjq1rA2DzAppDFtSV8Pcc8Lh9DXDKoOo\", \"cachedResultUrl\": \"https://docs.google.com/spreadsheets/d/1kBzpaLtXwvksjq1rA2DzAppDFtSV8Pcc8Lh9DXDKoOo/edit?usp=drivesdk\", \"cachedResultName\": \"users-list\"}}, \"typeVersion\": 1}, {\"id\": \"e1612f82-15b8-4aa0-a358-d746d525a80b\", \"name\": \"No Operation, do nothing\", \"type\": \"n8n-nodes-base.noOp\", \"position\": [-700, 20], \"parameters\": {}, \"typeVersion\": 1}, {\"id\": \"71f0cc4d-5650-4b39-96ad-fa0c7ae014b3\", \"name\": \"formating PhoneNum\", \"type\": \"n8n-nodes-base.code\", \"position\": [-1400, 140], \"parameters\": {\"jsCode\": \"// Helper function to format phone numbers\\nconst formatPhoneNumber = (phoneNumber) => {\\n    if (!phoneNumber) return phoneNumber;\\n\\n    // Convert phoneNumber to a string if it\'s not already\\n    phoneNumber = String(phoneNumber);\\n\\n    // Remove all non-digit characters\\n    let cleanNumber = phoneNumber.replace(/[^0-9]/g, \'\');\\n\\n    // Check if the number starts with \'0\'\\n    if (cleanNumber.startsWith(\'0\')) {\\n        cleanNumber = cleanNumber.substring(1); // Remove the leading \'0\'\\n    }\\n    \\n    // Check if the number starts with \'972\' (already international format)\\n    if (!cleanNumber.startsWith(\'972\')) {\\n        cleanNumber = `972${cleanNumber}`; // Add country code\\n    }\\n\\n    // Return the cleaned and formatted number with a \'+\' prefix\\n    return `+${cleanNumber}`;\\n};\\n\\n// Loop through all items and format the phone numbers\\nfor (const item of items) {\\n    if (item.json.PhoneNum) {\\n        item.json.PhoneNum = formatPhoneNumber(item.json.PhoneNum);\\n    }\\n}\\n\\nreturn items;\\n\"}, \"typeVersion\": 2}, {\"id\": \"ed6e6380-875d-45f8-af45-dd4309f3c01a\", \"name\": \"Whatsapp sending\", \"type\": \"n8n-nodes-base.httpRequest\", \"position\": [-700, 220], \"parameters\": {\"url\": \"https://conversations.messagebird.com/v1/send\", \"body\": \"={\\n  \\\"to\\\": \\\"{{ $json.PhoneNum }}\\\",\\n  \\\"from\\\": \\\"ebab9201-1f43-45ca-981c-fa2bd4423944\\\",\\n  \\\"type\\\": \\\"hsm\\\",\\n  \\\"content\\\": {\\n    \\\"hsm\\\": {\\n      \\\"namespace\\\": \\\"6bd5ec22_8a5a_4879_89ba_d00ad2731227\\\",\\n      \\\"templateName\\\": \\\"payro_login_otp\\\",\\n      \\\"language\\\": {\\n        \\\"code\\\": \\\"he\\\"\\n      },\\n      \\\"components\\\": [\\n        {\\n          \\\"type\\\": \\\"body\\\",\\n          \\\"parameters\\\": [\\n            {\\n              \\\"type\\\": \\\"text\\\",\\n              \\\"text\\\": \\\"123456\\\"\\n            }\\n          ]\\n        },\\n        {\\n          \\\"type\\\": \\\"button\\\",\\n          \\\"sub_type\\\": \\\"url\\\",\\n          \\\"index\\\": 0,\\n          \\\"parameters\\\": [\\n            {\\n              \\\"type\\\": \\\"text\\\",\\n              \\\"text\\\": \\\"123456\\\"\\n            }\\n          ]\\n        }\\n      ]\\n    }\\n  }\\n}\\n\", \"method\": \"POST\", \"options\": {}, \"sendBody\": true, \"contentType\": \"raw\", \"sendHeaders\": true, \"authentication\": \"genericCredentialType\", \"genericAuthType\": \"httpHeaderAuth\", \"headerParameters\": {\"parameters\": [{\"name\": \"Authorization\", \"value\": \"AccessKey n50tvfjrEwnQp34ZNg3G4ZaCv\"}]}}, \"typeVersion\": 4.2}, {\"id\": \"a17f0a96-a9cd-4328-9ed1-28ce21cee213\", \"name\": \"update last message record\", \"type\": \"n8n-nodes-base.googleSheets\", \"position\": [-500, 220], \"parameters\": {\"columns\": {\"value\": {\"UserID\": \"={{ $(\'check if user has ever got messages \').item.json.UserID }}\", \"LastMessageSentAt\": \"={{$today.toLocaleString()}}\", \"EverReceivedMessage?\": \"1\"}, \"schema\": [{\"id\": \"UserID\", \"type\": \"string\", \"display\": true, \"removed\": false, \"required\": false, \"displayName\": \"UserID\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}, {\"id\": \"Name\", \"type\": \"string\", \"display\": true, \"removed\": true, \"required\": false, \"displayName\": \"Name\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}, {\"id\": \"PhoneNum\", \"type\": \"string\", \"display\": true, \"removed\": true, \"required\": false, \"displayName\": \"PhoneNum\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}, {\"id\": \"CreatedAt\", \"type\": \"string\", \"display\": true, \"removed\": true, \"required\": false, \"displayName\": \"CreatedAt\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}, {\"id\": \"EverReceivedMessage?\", \"type\": \"string\", \"display\": true, \"removed\": false, \"required\": false, \"displayName\": \"EverReceivedMessage?\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}, {\"id\": \"LastMessageSentAt\", \"type\": \"string\", \"display\": true, \"required\": false, \"displayName\": \"LastMessageSentAt\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}, {\"id\": \"row_number\", \"type\": \"string\", \"display\": true, \"removed\": true, \"readOnly\": true, \"required\": false, \"displayName\": \"row_number\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}], \"mappingMode\": \"defineBelow\", \"matchingColumns\": [\"UserID\"], \"attemptToConvertTypes\": false, \"convertFieldsToString\": false}, \"options\": {}, \"operation\": \"update\", \"sheetName\": {\"__rl\": true, \"mode\": \"list\", \"value\": \"gid=0\", \"cachedResultUrl\": \"https://docs.google.com/spreadsheets/d/1kBzpaLtXwvksjq1rA2DzAppDFtSV8Pcc8Lh9DXDKoOo/edit#gid=0\", \"cachedResultName\": \"Sheet1\"}, \"documentId\": {\"__rl\": true, \"mode\": \"list\", \"value\": \"1kBzpaLtXwvksjq1rA2DzAppDFtSV8Pcc8Lh9DXDKoOo\", \"cachedResultUrl\": \"https://docs.google.com/spreadsheets/d/1kBzpaLtXwvksjq1rA2DzAppDFtSV8Pcc8Lh9DXDKoOo/edit?usp=drivesdk\", \"cachedResultName\": \"users-list\"}}, \"typeVersion\": 4.5}, {\"id\": \"99f719da-9965-49be-b1b2-0ef1df255f6f\", \"name\": \"check if user has ever got messages \", \"type\": \"n8n-nodes-base.if\", \"position\": [-1000, 140], \"parameters\": {\"options\": {}, \"conditions\": {\"options\": {\"version\": 2, \"leftValue\": \"\", \"caseSensitive\": true, \"typeValidation\": \"loose\"}, \"combinator\": \"or\", \"conditions\": [{\"id\": \"4795f3d0-fd67-4256-9bf5-d65e8ff712c2\", \"operator\": {\"type\": \"string\", \"operation\": \"equals\"}, \"leftValue\": \"={{ $(\'Google Sheets Trigger\').item.json[\\\"EverReceivedMessage?\\\"] }}\", \"rightValue\": \"1\"}]}, \"looseTypeValidation\": true}, \"typeVersion\": 2.2}, {\"id\": \"68886e4f-e86a-4435-9943-9a98631c2165\", \"name\": \"Update sheet with fixed  PhoneNum\", \"type\": \"n8n-nodes-base.googleSheets\", \"position\": [-1200, 140], \"parameters\": {\"columns\": {\"value\": {\"UserID\": \"={{ $json.UserID }}\", \"PhoneNum\": \"={{ $json.PhoneNum }}\"}, \"schema\": [{\"id\": \"UserID\", \"type\": \"string\", \"display\": true, \"removed\": false, \"required\": false, \"displayName\": \"UserID\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}, {\"id\": \"Name\", \"type\": \"string\", \"display\": true, \"removed\": true, \"required\": false, \"displayName\": \"Name\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}, {\"id\": \"PhoneNum\", \"type\": \"string\", \"display\": true, \"removed\": false, \"required\": false, \"displayName\": \"PhoneNum\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}, {\"id\": \"CreatedAt\", \"type\": \"string\", \"display\": true, \"removed\": true, \"required\": false, \"displayName\": \"CreatedAt\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}, {\"id\": \"EverReceivedMessage?\", \"type\": \"string\", \"display\": true, \"removed\": true, \"required\": false, \"displayName\": \"EverReceivedMessage?\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}, {\"id\": \"LastMessageSentAt\", \"type\": \"string\", \"display\": true, \"removed\": true, \"required\": false, \"displayName\": \"LastMessageSentAt\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}, {\"id\": \"row_number\", \"type\": \"string\", \"display\": true, \"removed\": true, \"readOnly\": true, \"required\": false, \"displayName\": \"row_number\", \"defaultMatch\": false, \"canBeUsedToMatch\": true}], \"mappingMode\": \"defineBelow\", \"matchingColumns\": [\"UserID\"], \"attemptToConvertTypes\": false, \"convertFieldsToString\": false}, \"options\": {}, \"operation\": \"update\", \"sheetName\": {\"__rl\": true, \"mode\": \"list\", \"value\": \"gid=0\", \"cachedResultUrl\": \"https://docs.google.com/spreadsheets/d/1kBzpaLtXwvksjq1rA2DzAppDFtSV8Pcc8Lh9DXDKoOo/edit#gid=0\", \"cachedResultName\": \"Sheet1\"}, \"documentId\": {\"__rl\": true, \"mode\": \"list\", \"value\": \"1kBzpaLtXwvksjq1rA2DzAppDFtSV8Pcc8Lh9DXDKoOo\", \"cachedResultUrl\": \"https://docs.google.com/spreadsheets/d/1kBzpaLtXwvksjq1rA2DzAppDFtSV8Pcc8Lh9DXDKoOo/edit?usp=drivesdk\", \"cachedResultName\": \"users-list\"}}, \"typeVersion\": 4.5}]','{\"Whatsapp sending\": {\"main\": [[{\"node\": \"update last message record\", \"type\": \"main\", \"index\": 0}]]}, \"formating PhoneNum\": {\"main\": [[{\"node\": \"Update sheet with fixed  PhoneNum\", \"type\": \"main\", \"index\": 0}]]}, \"Google Sheets Trigger\": {\"main\": [[{\"node\": \"formating PhoneNum\", \"type\": \"main\", \"index\": 0}]]}, \"Update sheet with fixed  PhoneNum\": {\"main\": [[{\"node\": \"check if user has ever got messages \", \"type\": \"main\", \"index\": 0}]]}, \"check if user has ever got messages \": {\"main\": [[{\"node\": \"No Operation, do nothing\", \"type\": \"main\", \"index\": 0}], [{\"node\": \"Whatsapp sending\", \"type\": \"main\", \"index\": 0}]]}}','2025-03-30 08:09:41.788','2025-03-30 08:09:41.788','{\"executionOrder\": \"v1\"}',NULL,'{}','7ee5fa07-31e5-4609-a7b9-3d03a137d92c',0,'fj91AMu4CaRTZRBz',NULL,NULL),('calendar-sinc',0,'[{\"id\": \"60d930a5-4062-45de-8ff1-1d49819e1959\", \"name\": \"Schedule Trigger\", \"type\": \"n8n-nodes-base.scheduleTrigger\", \"position\": [-400, 80], \"parameters\": {\"rule\": {\"interval\": [{\"triggerAtHour\": 11}]}}, \"typeVersion\": 1.2}, {\"id\": \"9686e2d0-ef8f-4b77-8d6c-034fd923e2e0\", \"name\": \"Strava\", \"type\": \"n8n-nodes-base.strava\", \"position\": [-200, 80], \"parameters\": {\"limit\": 5, \"operation\": \"getAll\"}, \"typeVersion\": 1.1}, {\"id\": \"71f0851e-6917-4980-a689-15d20b7321ca\", \"name\": \"Google Calendar\", \"type\": \"n8n-nodes-base.googleCalendar\", \"position\": [420, 80], \"parameters\": {\"end\": \"={{ $json[\\\"end time\\\"] }}\", \"start\": \"={{ $json.start_date }}\", \"calendar\": {\"__rl\": true, \"mode\": \"list\", \"value\": \"a22febdaf21474735b650c3e0a7b579db065d7d2d5f48f2e241c98f8f8a3dbeb@group.calendar.google.com\", \"cachedResultName\": \"אימונים\"}, \"additionalFields\": {\"summary\": \"={{ $json.name }} of {{ $json.distance }} km\"}, \"useDefaultReminders\": \"={{ true }}\"}, \"typeVersion\": 1.3}, {\"id\": \"dda3d413-4558-43a3-860f-52dd4a3d83cc\", \"name\": \"Edit Fields and Fix Timezone Offset\", \"type\": \"n8n-nodes-base.set\", \"position\": [0, 0], \"parameters\": {\"options\": {}, \"assignments\": {\"assignments\": [{\"id\": \"38fb9790-9d2f-4d87-a27a-1bf85caa626f\", \"name\": \"name\", \"type\": \"string\", \"value\": \"={{ $json.name }}\"}, {\"id\": \"262d3952-a9db-4d06-8e3c-6e1aeb31f6d5\", \"name\": \"start_date\", \"type\": \"string\", \"value\": \"={{ $json.start_date }}\"}, {\"id\": \"fc03ba06-6113-4aee-a661-660456705b87\", \"name\": \"end time\", \"type\": \"string\", \"value\": \"={{ \\n  (() => {\\n      const startTime = new Date($json[\\\"start_date_local\\\"]);  // Convert to Date object\\n      const movingTimeInMinutes = Math.round($json[\\\"moving_time\\\"] / 60);  // Convert moving time from seconds to minutes\\n      const movingTimeInMilliseconds = movingTimeInMinutes * 60000;  // Convert to milliseconds\\n      const endTime = new Date(startTime.getTime() + movingTimeInMilliseconds - (2 * 60 * 60000));  // Subtract 2 hours in milliseconds to fix time zone offset\\n      return endTime.toISOString();  // Return result as ISO string\\n  })() \\n}}\"}, {\"id\": \"40b88b3f-b8a7-4e93-9c8f-8afb7dd9f404\", \"name\": \"distance\", \"type\": \"string\", \"value\": \"={{ Math.round($json.distance/1000) }}\"}]}}, \"typeVersion\": 3.4}, {\"id\": \"86473ab0-d4f5-48ce-bd77-f29995476070\", \"name\": \"Filter Today\'s Activities\", \"type\": \"n8n-nodes-base.filter\", \"position\": [220, 80], \"parameters\": {\"options\": {}, \"conditions\": {\"options\": {\"version\": 2, \"leftValue\": \"\", \"caseSensitive\": true, \"typeValidation\": \"strict\"}, \"combinator\": \"and\", \"conditions\": [{\"id\": \"0a82064c-434c-49df-8ccd-e9ff3fc81de3\", \"operator\": {\"type\": \"boolean\", \"operation\": \"equals\"}, \"leftValue\": \"={{ \\n  (() => {\\n      const startTime = new Date($json[\\\"start_date\\\"]);\\n      \\n      // Get today\'s date (UTC) and strip the time\\n      const today = new Date();\\n      const todayDateString = today.toISOString().split(\'T\')[0];\\n      \\n      // Get the date portion of the start time\\n      const startTimeDateString = startTime.toISOString().split(\'T\')[0];\\n      \\n      // Compare the dates\\n      return startTimeDateString === todayDateString;\\n  })()\\n}}\", \"rightValue\": true}]}}, \"typeVersion\": 2.2}, {\"id\": \"b5767454-453e-4867-9e18-0ee2cb6451b5\", \"name\": \"Schedule Trigger1\", \"type\": \"n8n-nodes-base.scheduleTrigger\", \"position\": [-420, 420], \"parameters\": {\"rule\": {\"interval\": [{\"field\": \"weeks\", \"triggerAtHour\": 9}]}}, \"typeVersion\": 1.2}, {\"id\": \"b73d7c3c-e845-49da-8816-1babefebdb97\", \"name\": \"Strava1\", \"type\": \"n8n-nodes-base.strava\", \"position\": [-200, 420], \"parameters\": {\"operation\": \"getAll\"}, \"typeVersion\": 1.1}, {\"id\": \"87f6011e-ef35-4cd9-afcf-8334c08b5fea\", \"name\": \"Filter Today\'s Activities2\", \"type\": \"n8n-nodes-base.filter\", \"position\": [0, 420], \"parameters\": {\"options\": {}, \"conditions\": {\"options\": {\"version\": 2, \"leftValue\": \"\", \"caseSensitive\": true, \"typeValidation\": \"loose\"}, \"combinator\": \"and\", \"conditions\": [{\"id\": \"0a82064c-434c-49df-8ccd-e9ff3fc81de3\", \"operator\": {\"type\": \"boolean\", \"operation\": \"equals\"}, \"leftValue\": \"={{ \\n  (() => {\\n      const startTime = new Date($json[\\\"start_date\\\"]);\\n      \\n      // Get today\'s date (UTC)\\n      const today = new Date();\\n      \\n      // Calculate the date 7 days ago\\n      const lastWeek = new Date(today);\\n      lastWeek.setDate(today.getDate() - 7);\\n      \\n      // Convert to strings for comparison (ignoring time)\\n      const startTimeDateString = startTime.toISOString().split(\'T\')[0];\\n      const lastWeekDateString = lastWeek.toISOString().split(\'T\')[0];\\n      const todayDateString = today.toISOString().split(\'T\')[0];\\n      \\n      // Check if the event is within the past week\\n      const isWithinWeek = startTimeDateString >= lastWeekDateString && startTimeDateString <= todayDateString;\\n      \\n      // Return 1 if true, otherwise 0\\n      return isWithinWeek ? 1 : 0;\\n  })()\\n}}\\n\", \"rightValue\": true}]}, \"looseTypeValidation\": true}, \"typeVersion\": 2.2}, {\"id\": \"dd3eb942-391c-4d98-9865-9e2513eb5d19\", \"name\": \"AI Agent\", \"type\": \"@n8n/n8n-nodes-langchain.agent\", \"position\": [220, 420], \"parameters\": {\"options\": {}}, \"typeVersion\": 1.8}, {\"id\": \"b764ca33-15ff-4969-b91f-fcf40d28ab41\", \"name\": \"OpenAI Chat Model\", \"type\": \"@n8n/n8n-nodes-langchain.lmChatOpenAi\", \"position\": [180, 640], \"parameters\": {\"model\": {\"__rl\": true, \"mode\": \"list\", \"value\": \"gpt-4o-mini\"}, \"options\": {}}, \"typeVersion\": 1.2}]','{\"Strava\": {\"main\": [[{\"node\": \"Filter Today\'s Activities\", \"type\": \"main\", \"index\": 0}]]}, \"Strava1\": {\"main\": [[{\"node\": \"Filter Today\'s Activities2\", \"type\": \"main\", \"index\": 0}]]}, \"Schedule Trigger\": {\"main\": [[{\"node\": \"Strava\", \"type\": \"main\", \"index\": 0}]]}, \"OpenAI Chat Model\": {\"ai_languageModel\": [[{\"node\": \"AI Agent\", \"type\": \"ai_languageModel\", \"index\": 0}]]}, \"Schedule Trigger1\": {\"main\": [[{\"node\": \"Strava1\", \"type\": \"main\", \"index\": 0}]]}, \"Filter Today\'s Activities\": {\"main\": [[{\"node\": \"Google Calendar\", \"type\": \"main\", \"index\": 0}]]}, \"Filter Today\'s Activities2\": {\"main\": [[{\"node\": \"AI Agent\", \"type\": \"main\", \"index\": 0}]]}}','2025-03-30 08:05:48.554','2025-03-30 08:05:48.554','{\"executionOrder\": \"v1\"}',NULL,'{}','5f282e83-bbfb-4234-be48-3d0d0761d7f9',0,'h75fjPi1F3ONvBws','{\"templateCredsSetupCompleted\": true}',NULL);
/*!40000 ALTER TABLE `workflow_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflow_history`
--

DROP TABLE IF EXISTS `workflow_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_history` (
  `versionId` varchar(36) NOT NULL,
  `workflowId` varchar(36) NOT NULL,
  `authors` varchar(255) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `nodes` json NOT NULL,
  `connections` json NOT NULL,
  PRIMARY KEY (`versionId`),
  KEY `IDX_1e31657f5fe46816c34be7c1b4` (`workflowId`),
  CONSTRAINT `FK_1e31657f5fe46816c34be7c1b4b` FOREIGN KEY (`workflowId`) REFERENCES `workflow_entity` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_history`
--

LOCK TABLES `workflow_history` WRITE;
/*!40000 ALTER TABLE `workflow_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflow_statistics`
--

DROP TABLE IF EXISTS `workflow_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_statistics` (
  `count` int DEFAULT '0',
  `latestEvent` datetime DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  `workflowId` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`workflowId`,`name`),
  KEY `idx_workflow_statistics_workflow_id` (`workflowId`),
  CONSTRAINT `fk_workflow_statistics_workflow_id` FOREIGN KEY (`workflowId`) REFERENCES `workflow_entity` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_statistics`
--

LOCK TABLES `workflow_statistics` WRITE;
/*!40000 ALTER TABLE `workflow_statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows_tags`
--

DROP TABLE IF EXISTS `workflows_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflows_tags` (
  `workflowId` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `tagId` varchar(36) NOT NULL,
  PRIMARY KEY (`workflowId`,`tagId`),
  KEY `idx_workflows_tags_workflow_id` (`workflowId`),
  KEY `fk_workflows_tags_tag_id` (`tagId`),
  CONSTRAINT `fk_workflows_tags_tag_id` FOREIGN KEY (`tagId`) REFERENCES `tag_entity` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_workflows_tags_workflow_id` FOREIGN KEY (`workflowId`) REFERENCES `workflow_entity` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows_tags`
--

LOCK TABLES `workflows_tags` WRITE;
/*!40000 ALTER TABLE `workflows_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflows_tags` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-30  8:31:54
